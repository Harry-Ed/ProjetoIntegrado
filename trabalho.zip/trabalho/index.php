<?php
	require_once('conexao/conexao.php');

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
		
		 <meta charset="utf-8">
		 
		 <meta name="viewport" content="width=device-width, initial-scale=1">
		
		 <title>Tela Inical - Food Waves</title>
		 
		 <link rel="stylesheet" type="text/css" href="css/estilo.css">
		 
</head>
<body>
	 <header> 
		<div class="cabecalho">
		 <img src="img/logo.png"> 
		 <nav class="tabela-menu">
			
			 <a class="menu" href="">Home</a>
			
			 <a class="menu" href="">Estoque</a>
			
			 <a class="menu" href="">Controle de Lucros</a>
			
			 <a class="menu" href="">Usuario</a>
			
			 <a class="saida">Sair</a>
			
			</nav>
		</header>
		<div class="container">
			<div>
				

			</div>

		</div>


</body>
</html>