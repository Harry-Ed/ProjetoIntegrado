
 <?php require_once('../conexao/conexao.php')  ?>
 
 <!DOCTYPE html>
   <html> 

     <head>

       <meta charset="utf-8">
  
       <meta name="viewport" content="width=device-width, initial-scale=1, shrink-tofit=no">
  
         <title>Food-Waves</title>

         <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Noto+Serif+Tibetan&amp;display=swap">
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Scheherazade+New&amp;display=swap">
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Suranna&amp;display=swap">
         <link rel="stylesheet" href="../assets/fonts/fontawesome-all.min.css">    
         <link rel="stylesheet" href="../assets/fonts/font-awesome.min.css">
         <link rel="stylesheet" href="../assets/fonts/fontawesome5-overrides.min.css">

   </head>

   <body class="page-top">
       
         <div id="wrapper">

                 <nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-success p-0">

                     <div class="container-fluid d-flex flex-column p-0">

                         <a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">

                             <div class="sidebar-brand-icon rotate-n-15"><i class="fas fa-laugh-wink"></i></div>

                             <div class="sidebar-brand-text mx-3"><span href="home"> Food-Waves  </span></div>

                         </a>

                             <hr class="sidebar-divider my-0">

                                 <ul class="navbar-nav text-light" id="accordionSidebar">

                                     <li class="nav-item"> <a class="nav-link " href="home"> <i class="fas fa-tachometer-alt">    </i> <span>Home</span></a> </li>

                                     <li class="nav-item"><a class="nav-link" href="usuarios"><i class="fas fa-user">                   </i> <span>Usuario</span></a> </li>
                                     
                                     <li class="nav-item"><a class="nav-link" href="fornecedor"><i class="fas fa-users">                   </i> <span>Fornecedores</span></a> </li>

                                     <li class="nav-item"><a class="nav-link" href="vendas"><i class="fas fa-bars">            </i><span>Vendas</span></a></li>

                                     <li class="nav-item"><a class="nav-link" href="estoque"><i class="fas fa-table">                   </i> <span>Estoque</span></a> </li>

                                     <li class="nav-item"><a class="nav-link" href="http://localhost/trabalho/"><i class="fas fa-sign-out-alt"><input type="hidden" name="desconectar" value="1"></form>    </i> <span>Desconectar</span></a> </li>

                                 </ul>

                                     <div class="text-center d-none d-md-inline">

                                         <button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button>

                                     </div>

                     </div>

                 </nav>
         
             <div class="d-flex flex-column" id="content-wrapper">
             
             
                 <div id="content">
                 
                     <nav class="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
                     
                         <div class="container-fluid"><button class="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button"><i class="fas fa-bars"></i></button>
                             
                             <form class="form-inline d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                             
                                 <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Procurar por...">
                                 
                                     <div class="input-group-append"><button class="btn btn-success py-0" type="button"><i class="fas fa-search"></i></button></div>
                             
                                 </div>
                            
                             </form>
                             
                             <ul class="navbar-nav flex-nowrap ml-auto">
                                 
                                 <li class="nav-item dropdown d-sm-none no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-toggle="dropdown" href="#"><i class="fas fa-search"></i></a>
                                 
                                     <div class="dropdown-menu dropdown-menu-right p-3 animated--grow-in" aria-labelledby="searchDropdown">
                                         
                                         <form class="form-inline mr-auto navbar-search w-100">
                                         
                                             <div class="input-group"><input class="bg-light form-control border-0 small" type="text" placeholder="Search for ...">
                                             
                                                 <div class="input-group-append"><button class="btn btn-primary py-0" type="button"><i class="fas fa-search"></i></button></div>
                                         
                                             </div>
                                         
                                         </form>
                                 
                                     </div>
                                 
                                 </li>
                                 
                                
                             
                                 <div class="d-none d-sm-block topbar-divider"></div>
                                     
                                     <li class="nav-item dropdown no-arrow">
                                 
                                         <div class="nav-item dropdown no-arrow"><a class="dropdown-toggle nav-link" aria-expanded="false" data-toggle="dropdown" href="#"><span class="d-none d-lg-inline mr-2 text-gray-600 small">
                                             
                                             Lucas
                                                 
                                             </span><img class="border rounded-circle img-profile" src="img/logo.png" ></a>
                                     
                                                 <div class="dropdown-menu shadow dropdown-menu-right animated--grow-in"><a class="dropdown-item" href="#"><i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Profile</a><a class="dropdown-item" href="#"><i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Settings</a><a class="dropdown-item" href=""><i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Activity log</a>
                                         
                                                     <div class="dropdown-divider"></div>
                                                         <a class="dropdown-item" href="login.php"><i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>&nbsp;Logout</a>
                                     
                                                 </div>
                                 
                                         </div>
                                     
                                     </li>
                             
                             </ul>
                       
                         </div>
                 
                     </nav>
                     <div class="container-fluid">
                         
                         <h3 class="text-dark mb-4">Usuários</h3>
                     
                             <div class="row mb-3">
                         
                                 <div class="col-lg-12">
                             
                                     <div class="card mb-3">
                                        
                                         <div class="card-body text-center shadow"><img class="rounded-circle mb-3 mt-4" src="../assets/img/foto.png"  width="300" height="300">
                                           
                                             <div class="mb-3"><button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#modalExemplo">Mudar foto</button>
                                              
                                                    
                                                 <div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         
                                                     <div class="modal-dialog" role="document">
                                             
                                                         <div class="modal-content">
                                            
                                                             <div class="modal-header">
                            
                                                                 <h5 class="modal-title" id="exampleModalLabel">Upload Foto</h5>
                                                                     
                                                                     <button type="button" class="close" data-dismiss="modal" aria-label="Fechar"><span aria-hidden="true">&times;</span></button>
                                                             </div>
                                                             <form method="post" action="../apps/bd/fotoatt.php" enctype="multipart/form-data">

                                                             <div class="modal-body">
                                                                <input type="file" name="nomearquivo" >    
                                                            </div>     
                                                                 <div class="modal-footer">

                                                                     

                                                                     <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>

                                                                     <button type="submit" class="btn btn-primary" name="salvar" >Salvar</button>
                                                        
                                                                 </div>
                                                             </form>
                                                         </div>
                                                     
                                                     </div>
                                                
                                                 </div>

                                             </div>
                                 
                                         </div>
                             
                                     </div>
                             
                                   </div>
                         
                                 <div class="col-lg-12">
                             
                                     <div class="row mb-3 d-none">
                                 
                                         <div class="col">
                                     
                                             <div class="card text-white bg-primary shadow">
                                         
                                                 <div class="card-body">
                                             
                                                     <div class="row mb-2">
                                                 
                                                         <div class="col">
                                                             
                                                             <p class="m-0">Peformance</p>
                                                             
                                                             <p class="m-0"><strong>65.2%</strong></p>
                                                 
                                                         </div>
                                                 
                                                         <div class="col-auto"><i class="fas fa-rocket fa-2x"></i></div>
                                             
                                                     </div>
                                             
                                                     <p class="text-white-50 small m-0"><i class="fas fa-arrow-up"></i>&nbsp;5% since last month</p>
                                         
                                                 </div>
                                     
                                             </div>
                                 
                                         </div>
                                 
                                         <div class="col">
                                     
                                             <div class="card text-white bg-success shadow">
                                         
                                                 <div class="card-body">
                                             
                                                     <div class="row mb-2">
                                                 
                                                         <div class="col">
                                                            
                                                            <p class="m-0">Peformance</p>
                                                     
                                                            <p class="m-0"><strong>65.2%</strong></p>
                                                 
                                                         </div>
                                                 
                                                         <div class="col-auto"><i class="fas fa-rocket fa-2x"></i></div>
                                             
                                                     </div>
                                                     
                                                     <p class="text-white-50 small m-0"><i class="fas fa-arrow-up"></i>&nbsp;5% since last month</p>
                                         
                                                 </div>
                                     
                                             </div>
                                 
                                         </div>
                             
                                     </div>
                             
                                     <div class="row">
                                 
                                         <div class="col">
                                     
                                             <div class="card shadow mb-3">
                                         
                                                 <div class="card-header py-3">
                                                     
                                                     <p class="text-success m-0 font-weight-bold">Configurações do Usuário</p>
                                         
                                                 </div>
                                         
                                                 <div class="card-body">
                                                   
                                                     <form method="post" action="../apps/bd/UsuariosAtt.php">
                                                 
                                                         <input type="hidden" name="update">
                                                             
                                                             <div class="form-row">
                                                     
                                                                 <div class="col">
                                                         
                                                                     <div class="form-group"><strong>Nome de Usuário</strong><input class="form-control" type="text" id="username" value="" name="nome"></div>
                                                     
                                                                 </div>
                                                     
                                                             
                                                                 <div class="col">
                                                         
                                                                     <div class="form-group"><strong>Cargo</strong><input class="form-control" type="text" id="setor"  value=""  name="setor" ></div>
                                                     
                                                                 </div>
                                                     
                                                 
                                                         </div>
                                                 
                                                             <div class="form-group"><button class="btn btn-success btn-sm" type="submit" id="refresh">Salvar alterações</button></div>
                                                      
                                                      </form>
                                         
                                                 </div>
                                     
                                             </div>
                                     
                                         </div>
                             
                                     </div>
                          
                                 </div>
                     
                             </div>
                     
                         </div>
             
                 </div>
             
                 <footer class="bg-white sticky-footer">
                 
                     <div class="container my-auto">
                     
                         <div class="text-center my-auto copyright"><span>Copyright © crm 2022</span></div>
                 
                     </div>
                
                 </footer>
         
             </div>
         
             <a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
         
         </div>
         
         <script src="../assets/js/jquery.min.js"></script>
         
         <script src="../assets/js/bootstrap.min.js"></script>
         
         <script src="../assets/js/bs-init.js"></script>
         
         <script src="../assets/js/bootstrap.js"></script>
         
         <script src="../assets/js/bootstrap.min.js"></script>
         
         <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.js"></script>
         
         <script src="../assets/js/jquery.js"></script>
         
         <script src="../assets/js/jquery.min.js"></script>
         
         <script src="../assets/js/mdb.js"></script>
         
         <script src="../assets/js/mdb.min.js"></script>
         
         <script src="../assets/js/popper.js"></script>
         
         <script src="../assets/js/popper.min.js"></script>
         
         <script src="../assets/js/theme.js"></script>
         
 </body>
 
 </html>