<?php
require_once('conexao/conexao.php');

?>
<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login - Food Waves</title>
	<link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
	<form action="index.php" method="post">
 	<div class="form">
 		<img src="img/logo.png">
 		<br><br>
 		<h2>Login</h2>
 		<input type="text" name="Login" id="login" placeholder="Nome">
 		<br><br>
 		<input type="password" name="senha" placeholder="senha">
		<br><br>
		<button type="submit" >Entrar</button>
		<hr>
		<div><a href="criar-conta.php" class="conta">Esqueceu senha?</a><div>
	     <div><a href="" class="conta">Criar conta!</a><div>
		
	 </div>
	
 	 </form>
	 	
 	 </body>
 </html>